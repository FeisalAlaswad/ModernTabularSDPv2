# R3.2 numbers for the manuscript and the response letter
_Mode 4; results root: /content/drive/MyDrive/Software_Defects_Revised/R3_2_sensitivity_tuning/SMOKE_

- Test 0, Mode 1: TabNet received no gradient update in some folds of 5 datasets; TabNet mean ROC-AUC 63.48 -> 51.82; deep-tabular gap 7.06 -> 10.94 pp (change +3.89, 95% CI [+1.03, +6.76], Holm p=0.026).
- Test 0, Mode 2: TabNet received no gradient update in some folds of 3 datasets; TabNet mean ROC-AUC 64.63 -> 61.14; deep-tabular gap 6.41 -> 7.58 pp (change +1.16, 95% CI [-0.75, +3.19], Holm p=0.329).
- Test 0, Mode 3: TabNet received no gradient update in some folds of 5 datasets; TabNet mean ROC-AUC 62.81 -> 46.98; deep-tabular gap 7.75 -> 13.03 pp (change +5.28, 95% CI [+3.43, +7.27], Holm p=<0.001).
- Test 0, Mode 4: TabNet received no gradient update in some folds of 3 datasets; TabNet mean ROC-AUC 65.44 -> 53.36; deep-tabular gap 5.75 -> 9.77 pp (change +4.03, 95% CI [+1.77, +6.09], Holm p=0.014).
- Test 0, untrained TabNet (mode: datasets): M1: CM1, EQ, KC3, MC2, MW1; M2: EQ, KC3, MC2; M3: CM1, EQ, KC3, MC2, MW1; M4: EQ, KC3, MC2
- Test A, DeepTabular: published Mode-4 gap 5.75 pp; re-run default gap 18.23 pp (TabNet with drop_last=False).
- Test A, Transformer: published Mode-4 gap 2.82 pp; re-run default gap 5.89 pp (TabNet with drop_last=False).
- Test A, DeepTabular, arm default: gap +18.23 pp [+14.88, +21.34], classical better on 17/17, Holm p=<0.001; shift vs default +0.00 pp [+nan, +nan], Holm p=n/a; small datasets +22.64, others +16.39.
- Test A, DeepTabular, arm batch_64: gap +10.75 pp [+7.95, +13.74], classical better on 16/17, Holm p=<0.001; shift vs default -7.48 pp [-9.69, -5.32], Holm p=<0.001; small datasets +14.91, others +9.02.
- Test A, DeepTabular, arm best_arm_per_dataset (oracle): gap +9.52 pp [+7.00, +12.32], classical better on 16/17, Holm p=<0.001; shift vs default -8.71 pp [-10.70, -6.66], Holm p=<0.001; small datasets +14.61, others +7.40.
- Test A, Transformer, arm default: gap +5.89 pp [+3.28, +8.30], classical better on 15/17, Holm p=0.003; shift vs default +0.00 pp [+nan, +nan], Holm p=n/a; small datasets +2.47, others +7.31.
- Test A, Transformer, arm batch_64: gap +3.81 pp [+1.11, +6.37], classical better on 14/17, Holm p=0.016; shift vs default -2.07 pp [-3.31, -0.88], Holm p=0.004; small datasets +0.87, others +5.04.
- Test A, Transformer, arm best_arm_per_dataset (oracle): gap +3.46 pp [+0.76, +6.01], classical better on 14/17, Holm p=0.016; shift vs default -2.43 pp [-3.53, -1.37], Holm p=<0.001; small datasets +0.58, others +4.66.
- Test B, best tuned neural model per fold (selected by inner CV) vs default RandomForest: RandomForest better by +2.75 pp [+nan, +nan], RandomForest better in 1/1 folds, Wilcoxon p=1.000.
- Test B, best tuned neural model per fold (selected by inner CV) vs default ExtraTrees: ExtraTrees better by +1.20 pp [+nan, +nan], ExtraTrees better in 1/1 folds, Wilcoxon p=1.000.
- Test B, models selected as strongest tuned neural model: FT-Transformer 1
- Test B, DeepTabular: gap default +15.68 pp [+nan, +nan] -> tuned +3.22 pp [+nan, +nan] (reduction 79%); tuning gain +12.46 pp; classical still better on 1/1 datasets; closed on: none.
- Test B, Transformer: gap default +1.50 pp [+nan, +nan] -> tuned +4.62 pp [+nan, +nan] (reduction -208%); tuning gain -3.12 pp; classical still better on 1/1 datasets; closed on: none.
- Test D, FT-Transformer compact_small_data: FS effect +3.77 pp [+1.49, +6.37], Holm p=0.033; ROC-AUC all features 72.65, FS 76.42.
- Test D, FT-Transformer default: FS effect +0.42 pp [-5.04, +5.27], Holm p=0.712; ROC-AUC all features 70.87, FS 71.30.
- Test D, FT-Transformer difference (compact - default): FS effect +3.35 pp [-2.26, +9.41], Holm p=0.349.

## Outcome per family (pre-specified rules)
- DeepTabular: **insufficient data (CI needs >= 2 datasets)**
- Transformer: **insufficient data (CI needs >= 2 datasets)**